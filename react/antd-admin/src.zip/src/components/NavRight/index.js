import React,{usestate,useEffect} from 'react';
import { Tag } from 'antd';
import { NavLink } from 'react-router-dom';
import axios from 'axios';
import { useEffect } from 'react';
import './index.css';

const NavRight = () => {
    const [tagList,setTagList] = useEffect9([])
    const getTagAPIList = () => {
        axios
        .get('/tags')
        .then(res => {
            console.log(res);
        })
    }
    useEffect(() => {
        getTagAPIList()
    },[])
    return (
        <div></div>
    )
}